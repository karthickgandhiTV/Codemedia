(()=>{var e={};e.id=646,e.ids=[646,888,660],e.modules={521:(e,t,s)=>{"use strict";s.a(e,async(e,a)=>{try{s.r(t),s.d(t,{config:()=>h,default:()=>u,getServerSideProps:()=>x,getStaticPaths:()=>p,getStaticProps:()=>m,reportWebVitals:()=>g,routeModule:()=>j,unstable_getServerProps:()=>v,unstable_getServerSideProps:()=>b,unstable_getStaticParams:()=>_,unstable_getStaticPaths:()=>f,unstable_getStaticProps:()=>y});var r=s(7093),i=s(5244),n=s(1323),o=s(9981),c=s(9413),l=s(3143),d=e([c,l]);[c,l]=d.then?(await d)():d;let u=(0,n.l)(l,"default"),m=(0,n.l)(l,"getStaticProps"),p=(0,n.l)(l,"getStaticPaths"),x=(0,n.l)(l,"getServerSideProps"),h=(0,n.l)(l,"config"),g=(0,n.l)(l,"reportWebVitals"),y=(0,n.l)(l,"unstable_getStaticProps"),f=(0,n.l)(l,"unstable_getStaticPaths"),_=(0,n.l)(l,"unstable_getStaticParams"),v=(0,n.l)(l,"unstable_getServerProps"),b=(0,n.l)(l,"unstable_getServerSideProps"),j=new r.PagesRouteModule({definition:{kind:i.x.PAGES,page:"/posts/[id]",pathname:"/posts/[id]",bundlePath:"",filename:""},components:{App:c.default,Document:o.default},userland:l});a()}catch(e){a(e)}})},6710:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a={aws_project_region:"us-east-1",aws_appsync_graphqlEndpoint:"https://3ttim2pfcnb2pohreot27dyiy4.appsync-api.us-east-1.amazonaws.com/graphql",aws_appsync_region:"us-east-1",aws_appsync_authenticationType:"API_KEY",aws_appsync_apiKey:"da2-xj7fakh6hrgqxgm2liikds6vx4",aws_cognito_identity_pool_id:"us-east-1:22cedf6a-92ff-44f8-a656-152360e32bd8",aws_cognito_region:"us-east-1",aws_user_pools_id:"us-east-1_1FWejtgYS",aws_user_pools_web_client_id:"cvrm5uc36b931tqrrojlql1of",oauth:{},aws_cognito_username_attributes:[],aws_cognito_social_providers:[],aws_cognito_signup_attributes:["EMAIL"],aws_cognito_mfa_configuration:"OFF",aws_cognito_mfa_types:["SMS"],aws_cognito_password_protection_settings:{passwordPolicyMinLength:8,passwordPolicyCharacters:[]},aws_cognito_verification_mechanisms:["EMAIL"],aws_user_files_s3_bucket:"codemedia0b154b38f2c64f76bf4fd9697f67604bf2c92-codemedia",aws_user_files_s3_bucket_region:"us-east-1"}},7830:(e,t,s)=>{"use strict";s.a(e,async(e,a)=>{try{s.d(t,{Z:()=>p});var r=s(997),i=s(1664),n=s.n(i),o=s(6689),c=s(5581),l=s(7567),d=s(9005),u=s(7624),m=e([l]);l=(m.then?(await m)():m)[0];let p=()=>{let[e,t]=(0,o.useState)(!1);async function s(){c.Hub.listen("auth",e=>{switch(e.payload.event){case"signIn":return t(!0);case"signOut":return t(!1)}});try{await c.Auth.currentAuthenticatedUser(),t(!0)}catch(e){}}return(0,o.useEffect)(()=>{s()},[]),r.jsx(l.pJ,{as:"nav",className:"bg-gradient-to-r from-black to-transparent",children:({open:t})=>(0,r.jsxs)(r.Fragment,{children:[r.jsx("div",{className:"mx-auto max-w-7xl px-2 sm:px-6 lg:px-8",children:(0,r.jsxs)("div",{className:"relative flex h-16 items-center justify-between",children:[r.jsx("div",{className:"absolute inset-y-0 left-0 flex items-center sm:hidden",children:(0,r.jsxs)(l.pJ.Button,{className:"inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-cyan-600 hover:text-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white",children:[r.jsx("span",{className:"sr-only",children:"Open main menu"}),t?r.jsx(d.Z,{className:"block h-6 w-6","aria-hidden":"true"}):r.jsx(u.Z,{className:"block h-6 w-6","aria-hidden":"true"})]})}),(0,r.jsxs)("div",{className:"flex flex-1 items-center justify-center sm:items-stretch sm:justify-start",children:[r.jsx("div",{className:"flex flex-shrink-0 items-center",children:r.jsx("img",{className:"h-8 w-auto",src:"https://tailwindui.com/img/logos/mark.svg?color=indigo&shade=500",alt:"Your Company"})}),r.jsx("div",{className:"hidden sm:ml-6 sm:block",children:(0,r.jsxs)("div",{className:"flex space-x-4",children:[r.jsx(n(),{legacyBehavior:!0,href:"/",children:r.jsx("a",{className:"text-gray-300 hover:bg-cyan-600 hover:text-white rounded-md px-3 py-2 text-sm font-medium",children:"Home"})}),r.jsx(n(),{legacyBehavior:!0,href:"/create-post",children:r.jsx("a",{className:"text-gray-300 hover:bg-cyan-600 hover:text-white rounded-md px-3 py-2 text-sm font-medium",children:"Create Post"})}),r.jsx(n(),{legacyBehavior:!0,href:"/profile",children:r.jsx("a",{className:"text-gray-300 hover:bg-cyan-600 hover:text-white rounded-md px-3 py-2 text-sm font-medium",children:"Profile"})}),e&&r.jsx(n(),{legacyBehavior:!0,href:"/my-posts",children:r.jsx("a",{className:"text-gray-300 hover:bg-cyan-600 hover:text-white rounded-md px-3 py-2 text-sm font-medium",children:"My Posts"})})]})})]})]})}),r.jsx(l.pJ.Panel,{className:"sm:hidden",children:(0,r.jsxs)("div",{className:"space-y-1 px-2 pb-3 pt-2",children:[r.jsx(n(),{legacyBehavior:!0,href:"/",children:r.jsx("a",{className:"text-gray-300 hover:bg-cyan-600 hover:text-white block rounded-md px-3 py-2 text-base font-medium",children:"Home"})}),r.jsx(n(),{legacyBehavior:!0,href:"/create-post",children:r.jsx("a",{className:"text-gray-300 hover:bg-cyan-600 hover:text-white block rounded-md px-3 py-2 text-base font-medium",children:"Create Post"})}),r.jsx(n(),{legacyBehavior:!0,href:"/profile",children:r.jsx("a",{className:"text-gray-300 hover:bg-cyan-600 hover:text-white block rounded-md px-3 py-2 text-base font-medium",children:"Profile"})}),e&&r.jsx(n(),{legacyBehavior:!0,href:"/my-posts",children:r.jsx("a",{className:"text-gray-300 hover:bg-cyan-600 hover:text-white block rounded-md px-3 py-2 text-base font-medium",children:"My Posts"})})]})})]})})};a()}catch(e){a(e)}})},7073:(e,t,s)=>{"use strict";var a=s(5581),r=s(6710);a.Amplify.configure(r.Z)},4921:(e,t,s)=>{"use strict";s.d(t,{Yr:()=>i,fR:()=>r,qb:()=>a});let a=`
  mutation CreatePost(
    $input: CreatePostInput!
    $condition: ModelPostConditionInput
  ) {
    createPost(input: $input, condition: $condition) {
      id
      title
      content
      username
      coverImage
      comments {
        nextToken
        __typename
      }
      createdAt
      updatedAt
      __typename
    }
  }
`,r=`
  mutation DeletePost(
    $input: DeletePostInput!
    $condition: ModelPostConditionInput
  ) {
    deletePost(input: $input, condition: $condition) {
      id
      title
      content
      username
      coverImage
      comments {
        nextToken
        __typename
      }
      createdAt
      updatedAt
      __typename
    }
  }
`,i=`
  mutation CreateComment(
    $input: CreateCommentInput!
    $condition: ModelCommentConditionInput
  ) {
    createComment(input: $input, condition: $condition) {
      id
      message
      post {
        id
        title
        content
        username
        coverImage
        createdAt
        updatedAt
        __typename
      }
      postID
      createdAt
      updatedAt
      createdBy
      __typename
    }
  }
`},980:(e,t,s)=>{"use strict";s.d(t,{aA:()=>r,xl:()=>a,zu:()=>i});let a=`
  query GetPost($id: ID!) {
    getPost(id: $id) {
      id
      title
      content
      username
      coverImage
      comments {
        nextToken
        __typename
      }
      createdAt
      updatedAt
      __typename
    }
  }
`,r=`
  query ListPosts(
    $filter: ModelPostFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listPosts(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        title
        content
        username
        coverImage
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`,i=`
  query PostsByUsername(
    $username: String!
    $sortDirection: ModelSortDirection
    $filter: ModelPostFilterInput
    $limit: Int
    $nextToken: String
  ) {
    postsByUsername(
      username: $username
      sortDirection: $sortDirection
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        title
        content
        username
        coverImage
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`},9413:(e,t,s)=>{"use strict";s.a(e,async(e,a)=>{try{s.r(t),s.d(t,{default:()=>o});var r=s(997);s(108),s(7073);var i=s(7830),n=e([i]);i=(n.then?(await n)():n)[0];let o=function({Component:e,pageProps:t}){return(0,r.jsxs)("div",{children:[r.jsx(i.Z,{}),r.jsx("div",{className:"py-8 px-16 bg-slate-100",children:r.jsx(e,{...t})})]})};a()}catch(e){a(e)}})},9981:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>i});var a=s(997),r=s(6859);function i(){return(0,a.jsxs)(r.Html,{lang:"en",children:[a.jsx(r.Head,{}),(0,a.jsxs)("body",{children:[a.jsx(r.Main,{}),a.jsx(r.NextScript,{})]})]})}},3143:(e,t,s)=>{"use strict";s.a(e,async(e,a)=>{try{s.r(t),s.d(t,{default:()=>g,getStaticPaths:()=>y,getStaticProps:()=>f});var r=s(997),i=s(5581),n=s(1163),o=s(6689),c=s(3135);s(6710);var l=s(980),d=s(4921),u=s(6555),m=s(5152),p=s.n(m),x=s(8350);s(4144);var h=e([c,u,x]);[c,u,x]=h.then?(await h)():h,p()(()=>Promise.resolve().then(s.t.bind(s,6057,23)),{loadableGenerated:{modules:["pages\\posts\\[id].js -> react-simplemde-editor"]},ssr:!1});let _={message:""};function g({post:e}){let[t,s]=(0,o.useState)(!1),[a,l]=(0,o.useState)(null),[m,p]=(0,o.useState)(_),[h,g]=(0,o.useState)(!1),y=(0,n.useRouter)(),{message:f}=m;if(y.isFallback)return r.jsx("div",{children:"Loading..."});async function v(){if(!f)return;let e=(0,u.v4)();m.id=e;try{await i.API.graphql({query:d.Yr,variables:{input:m},authMode:"AMAZON_COGNITO_USER_POOLS"})}catch(e){console.log(e)}y.push("/my-posts")}return r.jsx("div",{className:"min-h-screen flex flex-col bg-gradient-to-r from-blue-50 via-white to-blue-50",children:r.jsx("div",{className:"flex-grow container mx-auto px-4 py-12 max-w-4xl",children:(0,r.jsxs)("div",{className:"bg-white shadow-xl rounded-lg p-8",children:[r.jsx("h1",{className:"text-5xl font-bold text-gray-800 mt-4 tracking-wide",children:e.title}),a&&r.jsx("img",{src:a,className:"mt-6 rounded-lg shadow-lg transition transform hover:scale-105",alt:"Cover Image"}),(0,r.jsxs)("p",{className:"text-sm font-light text-gray-600 mt-4",children:["By ",e.username]}),r.jsx("div",{className:"mt-8 prose prose-lg text-gray-700",children:r.jsx(c.default,{children:e.content})}),t&&(0,r.jsxs)("div",{className:"mt-10",children:[r.jsx("button",{type:"button",className:"mb-4 bg-green-500 hover:bg-green-600 text-white font-semibold px-8 py-2 rounded-full shadow-md transition",onClick:function(){g(!h)},children:"Write a Comment"}),(0,r.jsxs)("div",{style:{display:h?"block":"none"},className:"mt-4",children:[r.jsx(x.TextAreaField,{label:"Write a comment",name:"comment",placeholder:"Share your thoughts...",rows:3,value:m.message,onChange:t=>p({...m,message:t.target.value,postID:e.id}),className:"border-gray-300 focus:ring-blue-500 focus:border-blue-500 rounded-lg"}),r.jsx("button",{onClick:v,type:"button",className:"mt-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-2 rounded-full shadow-md transition",children:"Save Comment"})]})]})]})})})}async function y(){return{paths:(await i.API.graphql({query:l.aA})).data.listPosts.items.map(e=>({params:{id:e.id}})),fallback:!0}}async function f({params:e}){let{id:t}=e;return{props:{post:(await i.API.graphql({query:l.xl,variables:{id:t}})).data.getPost},revalidate:1}}a()}catch(e){a(e)}})},108:()=>{},5581:e=>{"use strict";e.exports=require("aws-amplify")},2785:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},6689:e=>{"use strict";e.exports=require("react")},6405:e=>{"use strict";e.exports=require("react-dom")},6057:e=>{"use strict";e.exports=require("react-simplemde-editor")},997:e=>{"use strict";e.exports=require("react/jsx-runtime")},8350:e=>{"use strict";e.exports=import("@aws-amplify/ui-react")},8916:e=>{"use strict";e.exports=import("@react-aria/focus")},7001:e=>{"use strict";e.exports=import("@react-aria/interactions")},3135:e=>{"use strict";e.exports=import("react-markdown")},6555:e=>{"use strict";e.exports=import("uuid")},7147:e=>{"use strict";e.exports=require("fs")},1017:e=>{"use strict";e.exports=require("path")},2781:e=>{"use strict";e.exports=require("stream")},9796:e=>{"use strict";e.exports=require("zlib")}};var t=require("../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),a=t.X(0,[117,919,859,479],()=>s(521));module.exports=a})();